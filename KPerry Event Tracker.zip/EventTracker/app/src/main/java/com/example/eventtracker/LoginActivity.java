package com.example.eventtracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText mUsername, mPassword;
    Button mLogin, mRegister;
    DBHelper_Login DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mUsername   = (EditText) findViewById(R.id.username);
        mPassword   = (EditText) findViewById(R.id.password);
        mLogin      = (Button) findViewById(R.id.loginButton);
        mRegister   = (Button) findViewById(R.id.registerButton);
        DB          = new DBHelper_Login(this);

        // Button listeners
        mLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = mUsername.getText().toString();
                String password = mPassword.getText().toString();

                // If username/password fields aren't filled out then display a message
                if(TextUtils.isEmpty(user) || TextUtils.isEmpty(password) ) {
                    Toast.makeText(LoginActivity.this, "Please enter username & password", Toast.LENGTH_SHORT).show();
                }
                else {
                    Boolean checkUser = DB.checkUsername(user);
                    if(!checkUser) {
                        Toast.makeText(LoginActivity.this, "User does not exist.", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Boolean checkLogin = DB.checkUsernamePassword(user, password);
                        if (checkLogin) {
                            // Logs user in and moves to main screen
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(intent);
                        }
                        else {
                            Toast.makeText(LoginActivity.this, "Invalid Login Credentials", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

            }
        });

        mRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = mUsername.getText().toString();
                String password = mPassword.getText().toString();

                // If username/password fields aren't filled out then display a message
                if(TextUtils.isEmpty(user) || TextUtils.isEmpty(password) ) {
                    Toast.makeText(LoginActivity.this, "Please enter username & password", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkUser = DB.checkUsername(user);
                    // Check if username is taken before registering
                    if (checkUser) {
                        Toast.makeText(LoginActivity.this, "Username already exists.", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        DB.insertData(user, password);
                        Toast.makeText(LoginActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
                        // Move user to main screen with new account
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    }
                }

            }
        });
    }

    // TO DO: SMS NOTIFICATIONS
}