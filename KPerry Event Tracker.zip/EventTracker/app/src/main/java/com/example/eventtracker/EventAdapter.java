package com.example.eventtracker;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;



import org.w3c.dom.Text;

import java.util.ArrayList;


public class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {

    private final Context context;
    private final ArrayList<EventModel> eventModelArrayList;
    private String TAG;
    SQLiteDatabase sqLiteDatabase;





    // Constructor
    public EventAdapter(ArrayList<EventModel> eventModelArrayList, Context context) {
        this.context = context;
        this.eventModelArrayList = eventModelArrayList;
        this.sqLiteDatabase = sqLiteDatabase;


    }

    @NonNull
    @Override
    public EventAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_event_card, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventAdapter.ViewHolder holder, int position) {
        EventModel model = eventModelArrayList.get(position);

        holder.eventTitleTV.setText(model.getEventTitle());
        holder.eventDateTV.setText(model.getEventDate());
        holder.eventTimeTV.setText(model.getEventTime());

        // Edit button
        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Store event data in bundle and send to next page
                Bundle bundle = new Bundle();
                bundle.putInt("id", holder.getAdapterPosition());
                bundle.putString("title", model.getEventTitle());
                bundle.putString("date", model.getEventDate());
                bundle.putString("time", model.getEventTime());
                Log.d(TAG, "Bundle Made");
                Intent intent = new Intent(context, EditActivity.class);
                intent.putExtra("userdata", bundle);
                context.startActivity(intent);
            }
        });

        // Delete event
        holder.delete.setOnClickListener(new View.OnClickListener() {
            DBHelperEvents DB = new DBHelperEvents(context);
            @Override
            public void onClick(View view) {
                sqLiteDatabase = DB.getReadableDatabase();
                long deletion = sqLiteDatabase.delete("events", "_id= ? ", null);
                if(deletion != 1) {
                    Log.d(TAG, "Data deleted");
                    eventModelArrayList.remove(holder.getAdapterPosition());
                    notifyDataSetChanged();
                }
            }
        });


    }


    @Override
    public int getItemCount() {
        return eventModelArrayList.size();
    }



    public void updateData(ArrayList<EventModel> eventModelArrayList) {

    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private final TextView eventTitleTV;
        private final TextView eventDateTV;
        private final TextView eventTimeTV;
        ImageView delete, edit;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            eventTitleTV = itemView.findViewById(R.id.eventTitle);
            eventDateTV = itemView.findViewById(R.id.eventDate);
            eventTimeTV = itemView.findViewById(R.id.eventTime);

            edit = (ImageView)itemView.findViewById(R.id.editButton);
            delete = (ImageView) itemView.findViewById(R.id.deleteButton);

        }
    }
}

