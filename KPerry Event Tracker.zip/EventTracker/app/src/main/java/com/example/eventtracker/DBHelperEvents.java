package com.example.eventtracker;

import android.content.ClipData;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.media.metrics.Event;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHelperEvents extends SQLiteOpenHelper {
    String TAG;

    public static final String DBNAME   = "Events.db";
    private static final int VERSION    = 1;

    private static final String TABLE       = "events";
    private static final String COL_ID      = "_id";
    private static final String COL_TITLE   = "title";
    private static final String COL_DATE    = "date";
    private static final String COL_TIME    = "time";

    // Constructor
    public DBHelperEvents(Context context) {
        super(context, "Events.db", null, VERSION);
    }


    // Creates database table
    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table " + TABLE + " (" +
                COL_ID    + " integer primary key autoincrement, " +
                COL_TITLE + " text, " +
                COL_DATE  + " text, " +
                COL_TIME  + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop table if exists " + TABLE);
        onCreate(DB);
    }

    // Add a new event to table
    public void addNewEvent(String eventTitle, String eventDate, String eventTime) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COL_TITLE, eventTitle);
        contentValues.put(COL_DATE, eventDate);
        contentValues.put(COL_TIME, eventTime);

        DB.insert(TABLE, null, contentValues);
        DB.close();
    }

    // Method to read events
    public ArrayList<EventModel> readEvents() {
        SQLiteDatabase DB = this.getReadableDatabase();
        Cursor cursor = DB.rawQuery("SELECT * FROM " + TABLE, null);

        ArrayList<EventModel> eventModelArrayList = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                eventModelArrayList.add(new EventModel(
                        cursor.getString(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3)));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return eventModelArrayList;
    }

}
