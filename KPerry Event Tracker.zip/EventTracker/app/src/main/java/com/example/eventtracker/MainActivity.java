package com.example.eventtracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView eventRV;
    private ActionMode mActionMode;
    private DBHelperEvents DB;
    private EventAdapter eventAdapter;
    ArrayList<EventModel> eventModelArrayList;
    private String TAG;
    private Button mEditButton, mDeleteButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Event Tracker");

        // Initialize fields
        eventModelArrayList = new ArrayList<>();
        mActionMode = null;
        DB = new DBHelperEvents(MainActivity.this);

        // Display current events
        eventModelArrayList = DB.readEvents();
        eventAdapter = new EventAdapter(eventModelArrayList, MainActivity.this);
        eventRV = findViewById(R.id.eventRV);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(MainActivity.this, RecyclerView.VERTICAL, false);
        eventRV.setLayoutManager(linearLayoutManager);
        eventRV.setAdapter(eventAdapter);



    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu_home, menu);
        return true;
    }

    // TO DO: ADD SETTINGS AND ABOUT PAGE
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.action_add:
                intent = new Intent(MainActivity.this, NewEvent.class);
                startActivity(intent);
                Log.d(TAG, "ADD EVENT ACTIVITY CALL SUCCESSFUL");
                return true;
            case R.id.action_about:
                Toast.makeText(this, "action_about", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_settings:
                Toast.makeText(this, "action_settings", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

}








