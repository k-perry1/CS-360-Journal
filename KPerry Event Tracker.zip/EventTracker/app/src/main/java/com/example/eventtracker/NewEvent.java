package com.example.eventtracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class NewEvent extends AppCompatActivity {

    RecyclerView recyclerView;
    private EditText mEventTitle, mEventDate, mEventTime;
    private Button mCreateEvent;
    private DBHelperEvents DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_event);
        getSupportActionBar().setTitle("Add a New Event");

        mEventTitle = findViewById(R.id.editTextTitle);
        mEventDate = findViewById(R.id.editTextDate);
        mEventTime = findViewById(R.id.editTextTime);
        mCreateEvent = findViewById(R.id.confirmButton);

        DBHelperEvents DB = new DBHelperEvents(NewEvent.this);

        mCreateEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String eventTitle = mEventTitle.getText().toString();
                String eventDate = mEventDate.getText().toString();
                String eventTime = mEventTime.getText().toString();

                // If any of the fields are empty
                if (TextUtils.isEmpty(eventTitle) || TextUtils.isEmpty(eventDate) || TextUtils.isEmpty(eventTime)) {
                    Toast.makeText(NewEvent.this, "Required information missing", Toast.LENGTH_SHORT).show();
                } else {
                    DB.addNewEvent(eventTitle, eventDate, eventTime);

                    // Display success message and move back to homepage
                    Toast.makeText(NewEvent.this, "Event added", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);

                }
            }
        });

    }
}