package com.example.eventtracker;

public class EventModel {

    private String id;
    private String eventTitle;
    private String eventDate;
    private String eventTime;

    // Constructors
    public EventModel() {}

    public EventModel(String id, String eventTitle, String eventDate, String eventTime) {
        this.id = id;
        this.eventTitle = eventTitle;
        this.eventDate  = eventDate;
        this.eventTime  = eventTime;
    }

    // Getters


    public String getId() {
        return id;
    }

    public String getEventTitle() {
        return eventTitle;
    }

    public String getEventDate() {
        return eventDate;
    }

    public String getEventTime() {
        return eventTime;
    }

    // Settters


    public void setId(String id) {
        this.id = id;
    }

    public void setEventTitle(String eventTitle) {
        this.eventTitle = eventTitle;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public void setEventTime(String eventTime) {
        this.eventTime = eventTime;
    }
}
