package com.example.eventtracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    private EditText mEventTitle, mEventDate, mEventTime;
    private DBHelperEvents DB;
    SQLiteDatabase sqLiteDatabase;
    String id;
    String TAG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        mEventTitle = findViewById(R.id.editTextTitle);
        mEventDate = findViewById(R.id.editTextDate);
        mEventTime = findViewById(R.id.editTextTime);
        Button mUpdateEvent = findViewById(R.id.confirmButton);

        DBHelperEvents DB = new DBHelperEvents(EditActivity.this);

        // Put event data into edit text fields
        if(getIntent().getBundleExtra("userdata") != null) {
            Bundle bundle = getIntent().getBundleExtra("userdata");
            id = bundle.getString("_id");
            mEventTitle.setText(bundle.getString("title"));
            mEventDate.setText(bundle.getString("date"));
            mEventTime.setText(bundle.getString("time"));

        }


        // Updates selected event when confirmation button is clicked
        mUpdateEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get database and convert current values to be displayed
                sqLiteDatabase = DB.getWritableDatabase();
                ContentValues contentValues = new ContentValues();
                //Convert EditText to Strings
                String eventTitle = mEventTitle.toString();
                String eventDate = mEventDate.getText().toString();
                String eventTime = mEventTime.getText().toString();

                // Add to content values
                contentValues.put("title", eventTitle);
                contentValues.put("date", eventDate);
                contentValues.put("time", eventTime);


                // Update data and move back to main screen
                long result = sqLiteDatabase.update("events", contentValues, "_id= ? " + id, null);
                if (result != -1) {
                    Log.d(TAG, "Update Successful");
                    Intent intent = new Intent(EditActivity.this, MainActivity.class);
                    startActivity(intent);
                    Log.d(TAG, "Moving to main screen");
                } else {
                    Log.d(TAG,"Update Failed");
                }

            }
        });
    }


}